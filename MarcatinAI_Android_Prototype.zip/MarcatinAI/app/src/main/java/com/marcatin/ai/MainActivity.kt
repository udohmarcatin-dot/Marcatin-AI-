package com.marcatin.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF09090D)
private val Card = Color(0xFF15151C)
private val Purple = Color(0xFF7C3AED)
private val PurpleLight = Color(0xFFA855F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarcatinAIApp() }
    }
}

@Composable
fun MarcatinAIApp() {
    var screen by remember { mutableStateOf("home") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = PurpleLight
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "create" -> CreateScreen(onBack = { screen = "home" })
                else -> HomeScreen(onCreate = { screen = "create" })
            }
        }
    }
}

@Composable
fun HomeScreen(onCreate: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Marcatin ", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("AI", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = PurpleLight)
            Spacer(Modifier.weight(1f))
            Text("👑", fontSize = 22.sp)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171126)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(22.dp)) {
                Text("Turn Photos", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Into Movies", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = PurpleLight)
                Spacer(Modifier.height(8.dp))
                Text("Create AI videos from your photos and ideas.", color = Color.LightGray)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                    Text("Create Now ✨")
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("🎬", "Photo → AI Video", "Turn photos into movie scenes", Modifier.weight(1f), onCreate)
            FeatureCard("🗣️", "Talking Photo", "Make your photo talk", Modifier.weight(1f), onCreate)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("🎭", "AI Movie Scene", "Create scenes from text", Modifier.weight(1f), onCreate)
            FeatureCard("🎙️", "AI Voice", "Natural AI voices", Modifier.weight(1f), onCreate)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("M", fontSize = 28.sp, color = PurpleLight, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Saviour (Owner)", fontWeight = FontWeight.Bold)
                    Text("Free Owner Credits • Unlimited testing", color = Color.LightGray, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.weight(1f))
        Text("Home     Create     Credits     My Videos     Profile", color = Color.Gray, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun FeatureCard(icon: String, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(icon, fontSize = 24.sp)
            Spacer(Modifier.height(6.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun CreateScreen(onBack: () -> Unit) {
    var scene by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Romance") }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", fontSize = 36.sp, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(12.dp))
            Text("Photo → AI Video", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Text("Step 1 • Choose Photo", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        OutlinedButton(
            onClick = { },
            modifier = Modifier.fillMaxWidth().height(150.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("🖼️\nTap to upload photo", fontSize = 18.sp)
        }

        Text("Step 2 • Describe your scene", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        OutlinedTextField(
            value = scene,
            onValueChange = { scene = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
            label = { Text("Scene & dialogue") },
            placeholder = { Text("Example: A romantic evening by the beach...") }
        )

        Text("Step 3 • Choose style", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Romance", "Action", "Drama").forEach {
                FilterChip(selected = style == it, onClick = { style = it }, label = { Text(it) })
            }
        }

        Spacer(Modifier.weight(1f))
        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) {
            Text("Generate Video ✨", fontSize = 17.sp)
        }
    }
}
